﻿using Microsoft.AspNetCore.Mvc;

namespace CellPhoneB_Store.Areas.Admin.Controllers
{
    public class AppRolesController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
